function result = fromdB(dB)
    result = 10.^(dB/10);
end
