function dB = todB(x)
    dB = 10 * log10(x);
end
